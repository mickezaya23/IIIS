Twitter Proxy
=============

JavaScript & Object-Oriented PHP example of how to retrieve tweets in JSON format from Twitter's v1.1 API using OAuth.

Original procedural PHP code by Peter Mortensen (<a href="https://twitter.com/PeterMortensen" target="_blank">@PeterMortensen</a>), adapted by Mike Rogers (<a href="https://twitter.com/mikerogers0" target="_blank">@mikerogers0</a>).

http://parallax.exposecms.com/blog/view/3109/retrieving-tweets-from-the-twitter-v1-1-api-using-oauth-php-javascript
